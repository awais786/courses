$_L(["java.lang.RuntimeException"],"java.lang.ArrayStoreException",null,function(){
c$=$_T(java.lang,"ArrayStoreException",RuntimeException);
});
