$_L(["java.lang.LinkageError"],"java.lang.ClassFormatError",null,function(){
c$=$_T(java.lang,"ClassFormatError",LinkageError);
});
