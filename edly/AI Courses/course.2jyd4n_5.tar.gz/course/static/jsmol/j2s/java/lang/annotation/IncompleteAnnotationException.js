$_L(["java.lang.RuntimeException"],"java.lang.annotation.IncompleteAnnotationException",null,function(){
c$=$_C(function(){
this.$annotationType=null;
this.$elementName=null;
$_Z(this,arguments);
},java.lang.annotation,"IncompleteAnnotationException",RuntimeException);
$_K(c$,
function(annotationType,elementName){
$_R(this,java.lang.annotation.IncompleteAnnotationException,[("annotation.0")]);
this.$annotationType=annotationType;
this.$elementName=elementName;
},"Class,~S");
$_M(c$,"annotationType",
function(){
return this.$annotationType;
});
$_M(c$,"elementName",
function(){
return this.$elementName;
});
});
