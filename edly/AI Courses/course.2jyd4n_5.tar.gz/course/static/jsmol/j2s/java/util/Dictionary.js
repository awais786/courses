c$=$_T(java.util,"Dictionary");
$_K(c$,
function(){
});
