Clazz.declarePackage ("java.util.zip");
Clazz.load (["java.io.IOException"], "java.util.zip.ZipException", null, function () {
c$ = Clazz.declareType (java.util.zip, "ZipException", java.io.IOException);
});
