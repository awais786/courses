$_L(["java.lang.VirtualMachineError"],"java.lang.InternalError",null,function(){
c$=$_T(java.lang,"InternalError",VirtualMachineError);
});
