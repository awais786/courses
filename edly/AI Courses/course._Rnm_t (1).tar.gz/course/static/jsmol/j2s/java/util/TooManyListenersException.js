$_L(["java.lang.Exception"],"java.util.TooManyListenersException",null,function(){
c$=$_T(java.util,"TooManyListenersException",Exception);
});
