$_L(["java.util.Collection"],"java.util.List",null,function(){
$_I(java.util,"List",java.util.Collection);
});
